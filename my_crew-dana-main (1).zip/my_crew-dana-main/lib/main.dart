
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:my_crew/feature/core/app_widget.dart';
import 'package:my_crew/utils/shared/shared_prefs.dart';
import 'package:my_crew/utils/utils/utils.dart';

Future<void> main() async {
    WidgetsFlutterBinding.ensureInitialized();
    await Firebase.initializeApp();
    await SharedPrefs.instance.initPrefs();
    Utils.instance.changeDeviceOrientation(orientation: DeviceOrientation.portraitUp);
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const AppWidget();
  }
}