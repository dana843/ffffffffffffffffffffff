import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:my_crew/feature/model/message_model.dart';
import 'package:my_crew/feature/model/user_model.dart';
import 'package:my_crew/utils/constants/constants.dart';
import 'package:my_crew/utils/localization/string_keys.dart';
import 'package:my_crew/utils/utils/utils.dart';

class ChatViewModel extends GetxController {

  final FirebaseFirestore db = FirebaseFirestore.instance;
  final FirebaseAuth auth = FirebaseAuth.instance;

  TextEditingController tdMessage = TextEditingController();
  List<UserModel> myChatUsers = [];
  bool loading = false;

  void endLoading() {
    loading = false;
    update();
  }

  void startLoading() {
    loading = true;
    update();
  }

  late Rx<bool> notEmbtyMessage = Rx<bool>(false);

  void changeMessageLenght({required bool isNotEmbty}) {
    notEmbtyMessage.value = isNotEmbty;
  }

  Future<void> getMyChatUsers() async {
    myChatUsers.clear();
    startLoading();
    await db
        .collection(Constants.usersCollection)
        .doc(auth.currentUser?.uid)
        .get()
        .then((chats) async {
      chats.reference
          .collection(Constants.chatsCollection)
          .get()
          .then((value) async {
        for (var element in value.docs) {
          await db
              .collection(Constants.usersCollection)
              .where(FieldPath.documentId, isEqualTo: element.id)
              .get()
              .then((user) {
            myChatUsers.add(UserModel.fromDocumentSnapshot(user.docs.first));
          });
        }

        endLoading();
      });
    }).catchError((e) {
      Utils.instance.snackError(body: StringKeys.errorWhileLoadingYourChats.tr);
      endLoading();
    });
  }

  Stream<QuerySnapshot<Map<String, dynamic>>> getUser() {
    return db.collection(Constants.usersCollection).snapshots();
  }

  void sendMessage({required String recpientId}) async {
    if (tdMessage.text.toString().trim().isNotEmpty) {
    MessageModel message =
        MessageModel(message: tdMessage.text.toString().trim());
    tdMessage.clear();
    notEmbtyMessage.value = false;
    await _setDummyData(
      recpientId: recpientId,
    );
    await db
        .collection(Constants.usersCollection)
        .doc(auth.currentUser?.uid)
        .collection(Constants.chatsCollection)
        .doc(recpientId)
        .collection(Constants.messagesCollection)
        .add(message.toJson())
        .then((value) async {
      
      await db
          .collection(Constants.usersCollection)
          .doc(recpientId)
          .collection(Constants.chatsCollection)
          .doc(auth.currentUser?.uid)
          .collection(Constants.messagesCollection)
          .doc(value.id)
          .set(message.toJson());
    });
    }
  }

  Future<void> _setDummyData({
    required String recpientId,
  }) async {
    await db
        .collection(Constants.usersCollection)
        .doc(auth.currentUser?.uid)
        .collection(Constants.chatsCollection)
        .doc(recpientId)
        .set({'a': 'a'});

    await db
        .collection(Constants.usersCollection)
        .doc(recpientId)
        .collection(Constants.chatsCollection)
        .doc(auth.currentUser?.uid)
        .set({'a': 'a'});
  }

  Stream<QuerySnapshot<Map<String, dynamic>>> getChatMessages(
      {required String? recpientId}) {
    return db
        .collection(Constants.usersCollection)
        .doc(auth.currentUser?.uid)
        .collection(Constants.chatsCollection)
        .doc(recpientId)
        .collection(Constants.messagesCollection)
        .orderBy(MessageModel.sentAtKey, descending: true)
        .snapshots();
  }

  Future<void> deleteMessageFromMe({
    required String? recpientId,
    required String messageId,
  }) async {
    await db
        .collection(Constants.usersCollection)
        .doc(auth.currentUser?.uid)
        .collection(Constants.chatsCollection)
        .doc(recpientId)
        .collection(Constants.messagesCollection)
        .doc(messageId)
        .delete();
  }

  Future<void> deleteMessageFromAll({
    required String? recpientId,
    required String messageId,
  }) async {
    await deleteMessageFromMe(recpientId: recpientId, messageId: messageId);

    await db
        .collection(Constants.usersCollection)
        .doc(recpientId)
        .collection(Constants.chatsCollection)
        .doc(auth.currentUser?.uid)
        .collection(Constants.messagesCollection)
        .doc(messageId)
        .delete();
  }
}