
import 'package:cloud_firestore/cloud_firestore.dart';

class JobModel{

  JobModel({this.title, this.companyId, this.salary, this.jobType, this.description, this.openStatus, this.applicantsNumber = 0});

  String? id;
  String? title;
  String? description;
  String? salary;
  String? companyId;
  String? jobType;
  bool? openStatus;
  int? applicantsNumber;
  Timestamp? addedAt;


  static const String idKey = 'id';
  static const String titleKey = 'title';
  static const String descriptionKey = 'description';
  static const String applicantsNumberKey = 'applicants_number';
  static const String openStatusKey = 'open';
  static const String salaryKey = 'salary_range';
  static const String companyIdKey = 'company_id';
  static const String jobTypeKey = 'job_type';
  static const String addedAtKey = 'added_at';


  Map<String, dynamic> toJson({bool local = false, bool isUpdate = false}){
    return {
      if (isUpdate)... {
        idKey : id
      },
    titleKey : title,
    descriptionKey : description,
    salaryKey : salary,
    jobTypeKey : jobType,
    openStatusKey : openStatus,
    companyIdKey : companyId,
    applicantsNumberKey : applicantsNumber,
    addedAtKey : Timestamp.now()
    };
  }

  JobModel.fromJson(Map<String, dynamic> json, {bool local = false}){
    id = json[idKey];
    title = json[titleKey];
    description = json[descriptionKey];
    salary = json[salaryKey];
    jobType = json[jobTypeKey];
    openStatus = json[openStatusKey];
    companyId = json[companyIdKey];
    applicantsNumber = json[applicantsNumberKey];
    addedAt = json[addedAtKey];
  }

 JobModel.fromDocumentSnapshot(DocumentSnapshot<Map<String,dynamic>> snapshot){
  id = snapshot.id;
  title = snapshot.data()?[titleKey];
  description = snapshot.data()?[descriptionKey];
  salary = snapshot.data()?[salaryKey];
  jobType = snapshot.data()?[jobTypeKey];
  companyId = snapshot.data()?[companyIdKey];
  openStatus = snapshot.data()?[openStatusKey];
  applicantsNumber = snapshot.data()?[applicantsNumberKey];
  addedAt = snapshot.data()?[addedAtKey];
 }
}
