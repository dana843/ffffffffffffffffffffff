
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:my_crew/feature/core/theme/size/size_manager.dart';
import 'package:my_crew/feature/model/message_model.dart';
import 'package:my_crew/feature/model/user_model.dart';
import 'package:my_crew/feature/view/app/chat/chat_screen/widgets/chat_app_bar.dart';
import 'package:my_crew/feature/view/app/chat/chat_screen/widgets/chat_message_text_area.dart';
import 'package:my_crew/feature/view/app/chat/chat_screen/widgets/my_message_item.dart';
import 'package:my_crew/feature/view/app/chat/chat_screen/widgets/received_message.dart';
import 'package:my_crew/feature/view/app/widgets/empty_message.dart';
import 'package:my_crew/feature/view/app/widgets/loading.dart';
import 'package:my_crew/feature/view/widgets/app_back_button.dart';
import 'package:my_crew/feature/view_model/chat_view_model.dart';
import 'package:my_crew/utils/localization/string_keys.dart';
import 'package:my_crew/utils/utils/utils.dart';


class ChatScreen extends StatelessWidget {
  const ChatScreen({Key? key, required this.recpient}) : super(key: key);

  final UserModel recpient;

  @override
  Widget build(BuildContext context) {
    Utils.instance.screenUtil(context: context);
    return Scaffold(
      appBar: AppBar(
        leading: const AppBackButton(),
          title: ChatAppBAr(
            userModel: recpient,
          ),
          titleSpacing: 0),
      body: GetBuilder<ChatViewModel>(
        initState: (_){
          if (!Get.isRegistered<ChatViewModel>()) {
            Get.put(ChatViewModel());
          }
        },
        builder: (_) {
          return Column(
              children: [
                Expanded(child: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
                 stream: _.getChatMessages(recpientId: recpient.id),
                  builder: (context, snapshot) {
                    if (snapshot.connectionState == ConnectionState.waiting) {
                      return const Loading();
                    } else if(snapshot.hasData && snapshot.data!.docs.isNotEmpty) {
                    return ListView.builder(
                                 padding: EdgeInsets.symmetric(
                                    horizontal: SizeManager.w12, vertical: SizeManager.h12),
                                physics: const BouncingScrollPhysics(),
                                shrinkWrap: true,
                                reverse: true,
                                itemCount: snapshot.data!.docs.length,
                                itemBuilder: ((context, index){
                                  MessageModel message = MessageModel.fromQuerySnapshot(snapshot.data!.docs[index]);
                                  return message.senderId == _.auth.currentUser?.uid ? MyMessageItem(message: message, recpientId: recpient.id ?? '') : ReceivedMessageItem(message: message) ;
                                }),
                    );
                    }
                    return EmptyMessage(message: '${StringKeys.startChattingWith.tr} ${recpient.name}');
                  }
                )),
                ChatMessageTextArea(
                  recpient: recpient,
                )
              ],
            );
        }
      ),
    );
  }
}
