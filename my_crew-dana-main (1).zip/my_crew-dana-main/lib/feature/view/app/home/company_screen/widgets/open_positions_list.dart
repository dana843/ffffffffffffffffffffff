import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';
import 'package:my_crew/feature/core/theme/size/size_manager.dart';
import 'package:my_crew/feature/model/job_model.dart';
import 'package:my_crew/feature/view/app/home/company_screen/company_positions_screen.dart';
import 'package:my_crew/feature/view/app/home/home_screen/widgets/job_item.dart';
import 'package:my_crew/feature/view/app/widgets/list_label.dart';
import 'package:my_crew/feature/view_model/home_view_model.dart';
import 'package:my_crew/utils/localization/string_keys.dart';

class OpenPositionsList extends StatelessWidget {
  const OpenPositionsList({super.key, required this.companyId});
  final String companyId;
  @override
  Widget build(BuildContext context) {
    return GetBuilder<HomeViewModel>(
      builder: (_) {
        return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
          stream: _.getOpendPositions(companyId : companyId),
          builder: (context, snapshot) {
            if (snapshot.hasData && snapshot.data!.docs.isNotEmpty) {
            return Column(
              children: [
                      ListLabel(label: StringKeys.openPositions.tr, onPressed: (){
                        Get.to(()=> const CompanyPositionsScreen());
                      },),
                      ListView.separated(
                        shrinkWrap: true,
                        padding: EdgeInsets.zero,
                        physics: const NeverScrollableScrollPhysics(),
                        itemCount: snapshot.data!.docs.length,
                        itemBuilder: (context, index) => JobItem(job: JobModel.fromDocumentSnapshot(snapshot.data!.docs[index])),
                        separatorBuilder: (context, index) => SizedBox(height: SizeManager.h8,),
                      ),
              ],
            );
            }
            return const SizedBox();
          }
        );
      }
    );
  }
}