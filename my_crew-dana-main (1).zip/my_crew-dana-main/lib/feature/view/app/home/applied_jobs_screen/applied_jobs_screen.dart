import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:my_crew/feature/core/theme/size/size_manager.dart';
import 'package:my_crew/feature/view/app/home/applied_jobs_screen/widgets/applied_job_item.dart';
import 'package:my_crew/feature/view/app/widgets/empty_message.dart';
import 'package:my_crew/feature/view/widgets/app_back_button.dart';
import 'package:my_crew/feature/view_model/profile_view_model.dart';
import 'package:my_crew/utils/localization/string_keys.dart';

class AppliedJobsScreen extends StatelessWidget {
  const AppliedJobsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: const AppBackButton(),
        title: Text(StringKeys.appliedJobs.tr),
      ),
      body: GetBuilder<ProfileViewModel>(
        initState: (_) {
          WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
            _.controller?.getAppliedJobs();
           });
        },
        builder: (_) {
          return _.jobs.isEmpty ? EmptyMessage(message: StringKeys.thereIsNoAppiedJobs.tr) : ListView.separated(
            padding: EdgeInsets.symmetric(
                horizontal: SizeManager.w12, vertical: SizeManager.h16),
            itemCount: _.applications.length,
            itemBuilder: (context, index) => AppliedJobItem(
              job: _.jobs[index],
              application: _.applications[index],
            ),
            separatorBuilder: (context, index) => SizedBox(
              height: SizeManager.h8,
            ),
          );
        }
      ),
    );
  }
}
