import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:my_crew/feature/core/theme/size/size_manager.dart';
import 'package:my_crew/feature/model/notification_model.dart';
import 'package:my_crew/feature/view/app/home/notifications_screen/widgets/notification_item.dart';
import 'package:my_crew/feature/view/widgets/app_back_button.dart';
import 'package:my_crew/utils/constants/constants.dart';
import 'package:my_crew/utils/localization/string_keys.dart';
import 'package:my_crew/utils/shared/shared_prefs.dart';
import 'package:my_crew/utils/utils/utils.dart';

class NotificationsScreen extends StatelessWidget {
  const NotificationsScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Utils.instance.screenUtil(context: context);
    return Scaffold(
      appBar: AppBar(
          leading: SharedPrefs.instance.getUserData()?.accountType == Constants.companyAccount ? const AppBackButton() : null,
          title: Text(StringKeys.notifications.tr)),
      body: ListView(
        padding: EdgeInsets.symmetric(
          vertical: SizeManager.h16,
          horizontal: SizeManager.w2
        ),
        children: [ 
          NotificationItem(notification: NotificationModel(title: 'New message form Dana', body: 'Hi, what do you do?', time: '23m ago', imageUrl: 'https://firebasestorage.googleapis.com/v0/b/my-crew-1a333.appspot.com/o/Users%2FKBU8ntIm5vYq23EORTVBiyfISnM2?alt=media&token=db3d9464-ee96-41ec-be52-d49a288fc1e5')),
          SizedBox( height: SizeManager.h4,),
          NotificationItem(notification: NotificationModel(title: 'Accepted application', body: 'Dana company was accepted your application', time: '3h ago',icon: Icons.account_balance_sharp , imageUrl: 'https://firebasestorage.googleapis.com/v0/b/my-crew-1a333.appspot.com/o/Users%2FXadNBwoyIgO8R7na1auuV4AbDF63?alt=media&token=dd022e4a-6307-4604-adad-e5b778ccb15f')),
          SizedBox( height: SizeManager.h4,),
          NotificationItem(notification: NotificationModel(title: 'New message form Dana', body: 'Hi, what do you do?', time: '23m ago', imageUrl: 'https://firebasestorage.googleapis.com/v0/b/my-crew-1a333.appspot.com/o/Users%2FKBU8ntIm5vYq23EORTVBiyfISnM2?alt=media&token=db3d9464-ee96-41ec-be52-d49a288fc1e5')),
        ]
      ),
    );
  }
}
