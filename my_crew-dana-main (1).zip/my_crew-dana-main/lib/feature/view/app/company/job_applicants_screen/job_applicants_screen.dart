import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:my_crew/feature/core/theme/size/size_manager.dart';
import 'package:my_crew/feature/view/app/company/job_applicants_screen/widgets/job_applicant_item.dart';
import 'package:my_crew/feature/view/app/widgets/empty_message.dart';
import 'package:my_crew/feature/view/widgets/app_back_button.dart';
import 'package:my_crew/feature/view_model/company/company_home_view_model.dart';
import 'package:my_crew/utils/localization/string_keys.dart';

class JobApplicantsScreen extends StatelessWidget {
  const JobApplicantsScreen({super.key, required this.jobId});

  final String jobId;
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: const AppBackButton(),
        title: Text(StringKeys.jobApplicants.tr),
      ),
      body: GetBuilder<CompanyHomeViewModel>(
        initState: (_){
          WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
            _.controller?.getJobApplications(jobId: jobId);
           });
        },
        builder: (_) {
          return _.applicants.isEmpty ? EmptyMessage(message: StringKeys.thereIsNoApplicantsYet.tr) : ListView.separated(
            padding: EdgeInsets.symmetric(
                horizontal: SizeManager.w12, vertical: SizeManager.h12),
            itemCount: _.applicants.length,
            itemBuilder: (context, index) => JobApplicantItem(applicant: _.applicants[index], application: _.applications[index],),
            separatorBuilder: (context, index) => SizedBox(height: SizeManager.h12),
          );
        }
      ),
    );
  }
}
