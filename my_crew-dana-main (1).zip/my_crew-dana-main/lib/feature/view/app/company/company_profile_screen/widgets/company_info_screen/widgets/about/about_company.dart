import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';
import 'package:my_crew/feature/view/app/company/company_profile_screen/widgets/company_info_screen/widgets/about/edit_about_company_dialog.dart';
import 'package:my_crew/feature/view/app/home/profile_screen/personal_info_screen/widgets/profile_info_section.dart';
import 'package:my_crew/feature/view_model/company/company_profile_view_model.dart';
import 'package:my_crew/utils/localization/string_keys.dart';
import 'package:my_crew/utils/shared/shared_prefs.dart';

class AboutCompany extends StatelessWidget {
  const AboutCompany({super.key});

  @override
  Widget build(BuildContext context) {
    return GetBuilder<CompanyProfileViewModel>(
      builder: (_) {
        return ProfileInfoSection(
            label: StringKeys.aboutCompany.tr,
            onPressed: (){
              Get.dialog(const EditAboutCompanyDialog());
              _.fillBio();
            },
            content: Text(
                SharedPrefs.instance.getUserData()?.bio ?? '',
                maxLines: 30,));
      }
    );
  }
}
